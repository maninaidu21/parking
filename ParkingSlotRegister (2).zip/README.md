# Parking Slot Register

A beginner friendly, menu driven Python application for tracking a small campus parking area. It stores records locally and works offline with the Python standard library.

## Requirements

- Python 3.10 or newer
- Windows, macOS, or Linux terminal
- No third party packages

## Run

Open a terminal in this folder and run:

```text
python main.py
```

On some systems, use `python3 main.py` instead. The starter register has 36 sample slots. The program saves changes in `data/parking_slots.json`; that file is included so the app opens with sample data on the first run.

## Menu

1. View all slots
2. Add a slot
3. Update a slot to Available, Occupied, Reserved, or Out of Service
4. Search by slot, zone, status, plate, vehicle type, or note
5. View totals, occupancy, per-zone availability, and a low-availability warning
6. Export timestamped CSV and Markdown reports in `exports/`
7. Import a CSV file with at least `slot_id`, `zone`, and `status` columns
0. Save and exit

Slot IDs must be unique and contain letters/numbers, optionally separated by hyphens. Occupied slots prompt for a plate and vehicle type. When a slot is marked as not occupied, plate and vehicle fields are cleared. CSV imports report invalid or duplicate rows and continue with valid rows.

## Data format

The JSON file is a list of records with these fields:

`slot_id`, `zone`, `status`, `vehicle_plate`, `vehicle_type`, `updated_at`, `notes`

Keep a backup of `data/parking_slots.json` before manually editing it. The app handles missing or unreadable files by starting with an empty register and reports the issue in the terminal.

## Demo path

1. View all 36 slots.
2. Try adding an occupied slot; enter a unique ID and a plate.
3. Update a sample slot to Available and note that its vehicle details clear.
4. Search for a zone such as `North` or a status such as `Reserved`.
5. Open the summary to see availability by zone.
6. Export the CSV and Markdown reports.
7. Exit, relaunch, and view the register to show that changes persisted.

## Project files

- `main.py` - application, validation, persistence, import/export, and reporting
- `data/parking_slots.json` - 36 realistic starter records
- `PROJECT_REPORT.md` - project documentation and design summary
- `LICENSE` - MIT license


## Browser preview

Open index.html in a browser for a visual walkthrough. The browser page is a small demonstration with session-only interactions; the Python terminal app is the version that writes records and reports to disk.

