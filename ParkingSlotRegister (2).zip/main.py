"""Parking Slot Register - a small, zero-dependency campus parking manager."""

from __future__ import annotations

import csv
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "parking_slots.json"
EXPORT_DIR = ROOT / "exports"
FIELDS = ("slot_id", "zone", "status", "vehicle_plate", "vehicle_type", "updated_at", "notes")
STATUSES = ("Available", "Occupied", "Reserved", "Out of Service")
VEHICLE_TYPES = ("Car", "Motorcycle", "Bicycle", "Other")


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="minutes")


def clean(value: str, limit: int = 80) -> str:
    return " ".join(value.strip().split())[:limit]


def load_slots() -> list[dict[str, str]]:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        DATA_FILE.write_text("[]\n", encoding="utf-8")
    try:
        raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("the top level must be a list")
        slots = []
        seen = set()
        for item in raw:
            if not isinstance(item, dict) or not all(key in item for key in FIELDS):
                continue
            slot = {key: clean(str(item[key]), 120) for key in FIELDS}
            slot["slot_id"] = slot["slot_id"].upper()
            if slot["slot_id"] and slot["slot_id"] not in seen and slot["status"] in STATUSES:
                slots.append(slot)
                seen.add(slot["slot_id"])
        return slots
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"Could not read {DATA_FILE.name}: {exc}. Starting with an empty register.")
        return []


def save_slots(slots: list[dict[str, str]]) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = DATA_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(slots, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(DATA_FILE)


def prompt(label: str, *, required: bool = True, limit: int = 80) -> str:
    while True:
        value = clean(input(label), limit)
        if value or not required:
            return value
        print("This field is required.")


def choose(label: str, choices: tuple[str, ...]) -> str:
    while True:
        for number, value in enumerate(choices, 1):
            print(f"  {number}. {value}")
        answer = input(label).strip()
        if answer.isdigit() and 1 <= int(answer) <= len(choices):
            return choices[int(answer) - 1]
        match = next((choice for choice in choices if choice.casefold() == answer.casefold()), None)
        if match:
            return match
        print("Choose a listed number or value.")


def table(slots: list[dict[str, str]]) -> None:
    if not slots:
        print("No matching parking slots.")
        return
    widths = {key: min(max(len(key.replace("_", " ")), *(len(row[key]) for row in slots)), 23) for key in FIELDS}
    header = " | ".join(key.replace("_", " ").title().ljust(widths[key]) for key in FIELDS)
    print(header)
    print("-+-".join("-" * widths[key] for key in FIELDS))
    for row in slots:
        print(" | ".join(row[key][:widths[key]].ljust(widths[key]) for key in FIELDS))


def add_slot(slots: list[dict[str, str]]) -> None:
    existing = {row["slot_id"] for row in slots}
    while True:
        slot_id = prompt("Slot ID (for example A-01): ", limit=12).upper()
        if re.fullmatch(r"[A-Z0-9]+(?:-[A-Z0-9]+)*", slot_id) and slot_id not in existing:
            break
        print("Use letters/numbers with optional hyphens, and choose a unique ID.")
    zone = prompt("Zone/building: ", limit=40)
    status = choose("Initial status: ", STATUSES)
    plate = prompt("Vehicle plate (blank unless occupied): ", required=False, limit=20).upper()
    vehicle = ""
    if status == "Occupied":
        if not plate:
            plate = prompt("Vehicle plate: ", limit=20).upper()
        vehicle = choose("Vehicle type: ", VEHICLE_TYPES)
    elif plate:
        print("Plate ignored because this slot is not occupied.")
        plate = ""
    slots.append(dict(slot_id=slot_id, zone=zone, status=status, vehicle_plate=plate,
                      vehicle_type=vehicle, updated_at=now(), notes=prompt("Notes (optional): ", required=False)))
    save_slots(slots)
    print(f"Slot {slot_id} added.")


def update_slot(slots: list[dict[str, str]]) -> None:
    slot_id = prompt("Slot ID to update: ", limit=12).upper()
    row = next((item for item in slots if item["slot_id"] == slot_id), None)
    if not row:
        print("Slot not found.")
        return
    print(f"Current status: {row['status']}")
    status = choose("New status: ", STATUSES)
    plate, vehicle = "", ""
    if status == "Occupied":
        plate = prompt("Vehicle plate: ", limit=20).upper()
        vehicle = choose("Vehicle type: ", VEHICLE_TYPES)
    row.update(status=status, vehicle_plate=plate, vehicle_type=vehicle, updated_at=now())
    note = prompt("Update note (blank to keep existing): ", required=False)
    if note:
        row["notes"] = note
    save_slots(slots)
    print(f"Slot {slot_id} updated.")


def search(slots: list[dict[str, str]]) -> None:
    term = prompt("Search slot, zone, status, plate, type, or notes: ", limit=80).casefold()
    table([row for row in slots if any(term in row[key].casefold() for key in FIELDS)])


def summary(slots: list[dict[str, str]]) -> None:
    counts = Counter(row["status"] for row in slots)
    total = len(slots)
    available = counts["Available"]
    occupied = counts["Occupied"]
    occupancy = (occupied / total * 100) if total else 0
    print("\nPARKING SUMMARY")
    print(f"Total slots: {total} | Available: {available} | Occupied: {occupied} | Reserved: {counts['Reserved']} | Out of service: {counts['Out of Service']}")
    print(f"Occupancy: {occupancy:.1f}%")
    if total and available / total <= 0.10:
        print("WARNING: 10% or fewer slots are available.")
    if total:
        zones = sorted({row["zone"] for row in slots})
        print("\nBy zone:")
        for zone in zones:
            group = [row for row in slots if row["zone"] == zone]
            free = sum(row["status"] == "Available" for row in group)
            print(f"  {zone}: {free}/{len(group)} available ({len(group) - free} occupied/reserved/out of service)")
    print()


def export(slots: list[dict[str, str]]) -> None:
    EXPORT_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    csv_path = EXPORT_DIR / f"parking-report-{stamp}.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(slots)
    counts = Counter(row["status"] for row in slots)
    total = len(slots)
    lines = ["# Parking Slot Register Summary", "", f"Generated: {now()}", "",
             f"- Total slots: {total}", f"- Available: {counts['Available']}",
             f"- Occupied: {counts['Occupied']}", f"- Reserved: {counts['Reserved']}",
             f"- Out of service: {counts['Out of Service']}",
             f"- Occupancy: {(counts['Occupied'] / total * 100) if total else 0:.1f}%", "", "## Slots", "",
             "| Slot | Zone | Status | Plate | Vehicle | Updated | Notes |", "|---|---|---|---|---|---|---|"]
    for row in slots:
        values = [row[k].replace("|", "\\|") for k in FIELDS]
        lines.append("| " + " | ".join(values) + " |")
    md_path = EXPORT_DIR / f"parking-report-{stamp}.md"
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Reports saved:\n  {csv_path.name}\n  {md_path.name}")


def import_csv(slots: list[dict[str, str]]) -> None:
    path = Path(prompt("CSV path to import: ", limit=240)).expanduser()
    if not path.is_file():
        print("File not found.")
        return
    existing = {row["slot_id"] for row in slots}
    added, skipped = 0, 0
    try:
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames or not {"slot_id", "zone", "status"}.issubset(reader.fieldnames):
                print("CSV must include slot_id, zone, and status columns.")
                return
            for line, item in enumerate(reader, 2):
                slot_id = clean(item.get("slot_id", ""), 12).upper()
                status = clean(item.get("status", ""), 30).title()
                if not re.fullmatch(r"[A-Z0-9]+(?:-[A-Z0-9]+)*", slot_id) or slot_id in existing or status not in STATUSES:
                    print(f"Row {line}: skipped (invalid ID, duplicate ID, or invalid status).")
                    skipped += 1
                    continue
                row = {key: clean(item.get(key, ""), 120) for key in FIELDS}
                row.update(slot_id=slot_id, status=status, updated_at=row["updated_at"] or now())
                if status != "Occupied":
                    row["vehicle_plate"] = row["vehicle_type"] = ""
                slots.append(row)
                existing.add(slot_id)
                added += 1
        save_slots(slots)
        print(f"Imported {added} row(s); skipped {skipped}.")
    except (OSError, csv.Error, UnicodeError) as exc:
        print(f"Import failed: {exc}")


def main() -> None:
    slots = load_slots()
    actions = {"1": lambda: table(slots), "2": lambda: add_slot(slots), "3": lambda: update_slot(slots),
               "4": lambda: search(slots), "5": lambda: summary(slots), "6": lambda: export(slots),
               "7": lambda: import_csv(slots)}
    print("\nPARKING SLOT REGISTER")
    while True:
        print("\n1. View all slots\n2. Add a slot\n3. Update slot status\n4. Search slots\n5. Summary & availability\n6. Export reports\n7. Import CSV\n0. Save and exit")
        choice = input("Select an option: ").strip()
        if choice == "0":
            save_slots(slots)
            print("Saved. Goodbye!")
            break
        action = actions.get(choice)
        if action:
            try:
                action()
            except (KeyboardInterrupt, EOFError):
                print("\nAction cancelled.")
        else:
            print("Enter a number from 0 to 7.")


if __name__ == "__main__":
    main()
