# Parking Slot Register - Project Report

## 1. Introduction

Parking areas in small campuses often rely on fragmented notes or manual counts. This project provides a lightweight local register that records each parking slot, its zone, current availability, and vehicle details when occupied. It is designed for a beginner friendly Python demonstration and needs no internet connection or external packages.

## 2. Objectives

- Record and update parking slot status through a guided terminal menu.
- Validate slot IDs, choices, and required values before saving.
- Preserve records across program restarts using JSON.
- Find records quickly and summarize overall and per-zone availability.
- Exchange records through CSV and produce readable CSV and Markdown reports.

## 3. Scope and assumptions

Each slot has one current status: Available, Occupied, Reserved, or Out of Service. A plate and vehicle type are stored only while a slot is Occupied. The app is intended for one local operator at a time; it does not provide accounts, network synchronization, payment, or reservation scheduling. The sample set contains 36 slots across North, Central, and South zones.

## 4. Technology

The application uses Python 3.10+ and the standard library: `json` and `csv` for data interchange, `pathlib` for portable file paths, `datetime` for timestamps, `collections.Counter` for aggregation, and `re` for slot ID validation. JSON is the source of truth; CSV is used for bulk import and exported reports.

## 5. Data design

Each record stores `slot_id`, `zone`, `status`, `vehicle_plate`, `vehicle_type`, `updated_at`, and `notes`. Slot IDs are unique. Updates are written to a temporary file and then replace the data file, reducing the chance of a partially written register. Missing data creates an empty register. Invalid JSON is reported and the program remains usable without silently overwriting the unreadable source.

## 6. Main workflows

1. **View and search:** display records in a fixed-width terminal table; search across all fields.
2. **Add a slot:** validate a unique ID, collect the zone and status, and request vehicle details only when occupied.
3. **Update status:** change a slot status; clear plate/type when it becomes non-occupied.
4. **Summary:** compute counts and occupancy percentage, show free slots by zone, and warn when availability is at or below 10%.
5. **Import:** read CSV rows, validate required columns, IDs, duplicates, and statuses, then report skipped row numbers.
6. **Export:** produce timestamped CSV and Markdown files containing a snapshot and summary.

## 7. Validation and error handling

The menu accepts only listed options. Required input loops until non-empty. IDs are checked against a restricted pattern and duplicates are rejected. Status and vehicle type selections accept either the displayed number or an exact case-insensitive label. File and CSV errors are caught and reported to the operator. Import errors are isolated per row so valid rows can still be brought in.

## 8. Example demonstration

Launch the program, inspect the 36 seeded slots, add a new occupied slot, then mark it available. Search for a zone and open the summary to compare per-zone capacity. Export reports, exit, and launch again to demonstrate local persistence.

## 9. Limitations and future work

The program is single-user and stores only the latest state, not a full audit history. Future improvements could include role based access, a GUI, reservation time windows, audit logs, configurable capacity warnings, and automated backup rotation. For simultaneous users, a database and concurrency controls would be needed.

## 10. Conclusion

Parking Slot Register demonstrates structured records, input validation, file persistence, search, aggregation, and export using core Python. It provides a practical base for a small parking operation and a clear terminal demo for the requested project brief.

